إصلاح Workflow الموقع

الملف داخل الأرشيف موجود بالمسار الصحيح:
.github/workflows/publish-refund-policy.yml

استبدل به الملف الحالي بنفس الاسم داخل مستودع surveyquant-website، ولا تضفه كملف Workflow جديد حتى لا تظل النسخة القديمة الفاشلة موجودة. بعد الحفظ افتح GitHub Actions وشغّل: Publish SurveyQuant Refund Policy, WhatsApp and 7-Day Trial.

التعديل خاص بصفحات الموقع فقط، ولا يغير مدة التجربة داخل APK أو الخادم الخلفي. الموقع يوضح أن الدفع الإلكتروني غير مفعّل حاليًا، وأي استرجاع يظل بعد التحقق من الخصم وحالة العملية.
